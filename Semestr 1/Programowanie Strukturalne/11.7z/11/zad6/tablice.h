//
// Created by user on 14-Jan-25.
//
#include <stdio.h>
#include <stdlib.h>
#include "tablice.c"

int *stworz(int n);
void wyswietl(int * tablica, int n);
void usun(int*);

