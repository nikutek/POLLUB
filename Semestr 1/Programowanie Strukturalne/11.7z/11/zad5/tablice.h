//
// Created by student on 09.01.2025.
//

#ifndef TABLICE_H
#define TABLICE_H

#endif //TABLICE_H

int* stworzTablice();
void wyswietlTablice();
void usunTablice();
int losuj;