#include <stdio.h>
#include <stdlib.h>
#include "tablice.c"

int main(void) {
    printf("Hello, World!\n");
    int* tablica = stworzTablice();
    return 0;
}
