//
// Created by user on 14-Jan-25.
//
#ifndef TABLICE_H
#define TABLICE_H

#endif //TABLICE_H

float* stworz(int n);
void wysiwetl(float* tablica, int n);
void usun(float* tablica);

