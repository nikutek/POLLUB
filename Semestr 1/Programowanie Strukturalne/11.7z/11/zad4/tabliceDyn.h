//
// Created by student on 09.01.2025.
//

#ifndef TABLICEDYN_H
#define TABLICEDYN_H

#endif //TABLICEDYN_H

int* stworzTablice(int rozmiar);
void wyswietlTablice(int *tablica);
void usunTablice(int *tablica);
